mvsn_test <-  function(y){
  dname <- deparse(substitute(y))
  if(is.vector(y) == TRUE) y = cbind(y)
  stopifnot(is.matrix(y))
  n     <-  nrow(y)
  if (n < 12 || n > 5000) 
    stop("Sample size must be between 12 and 5000.")
  p     <-  ncol(y)
  if(n <= p)
    stop("Sample size must be larger than vector dimension.")
  if(n > p)
  {
    n <- nrow(y)  # sample size
    p <- ncol(y)  # dimension

    # Parameter estimation
    X <- cbind(rep(1, n))
    fit <- msn.mle(x = X, y = y)
    xi.hat <- fit$dp$beta 
    Omega.hat <- fit$dp$Omega 
    alpha.hat <- fit$dp$alpha 

    # estimated canonical form
    y_hat <- canonical(y, alpha =alpha.hat, Omega = Omega.hat, xi = xi.hat)

    S <- apply(y_hat, 1, sum) # sum coordinates of canonical form 

    cp_w <- sn.mple(y = S, penalty = "Qpenalty", opt.method = "nlminb")$cp
    w    <- cp2dp(cp_w, family = "SN")
    
    n2   <- n / 2
    z    <- (S - w[1]) * rep(c(1,-1), n2)
    return(shapiro.test(z))
  }
}  
