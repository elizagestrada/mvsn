mvsn_shapiro <-  function(y){
    dname <- deparse(substitute(y))
    if(is.vector(y) == TRUE) y = cbind(y)
    stopifnot(is.matrix(y))
    n     <-  nrow(y)
    if (n < 12 || n > 5000) 
      stop("Sample size must be between 12 and 5000.")
    p     <-  ncol(y)
    if(n <= p)
      stop("Sample size must be larger than vector dimension.")
    if(n > p)
    {
      n <- NA
      p <- NA
      n <- nrow(y)
      p <- ncol(y)
      
      # Parameter estimation
      X <- cbind(rep(1, n))
      fit <- msn.mle(x = X, y = y)
      xi.hat <- fit$dp$beta 
      Omega.hat <- fit$dp$Omega 
      alpha.hat <- fit$dp$alpha 
      
      # data transformed to canonical form
      y_hat <- canonical(y, alpha =alpha.hat, Omega = Omega.hat, xi = xi.hat)
      
      n2    <- n / 2
      signs <- NA
      z     <- NA
      z     <- y_hat * rep(c(-1,1), n2)   # approx multivariate normal data
      
      w <- rep(NA,p)
      for(k in 1:p)
      {
        w[k]  <- shapiro.test(z[,k])$statistic
      }
      wast <- mean(w)
      u <- log(n)
      w1 <- log(1 - wast)
      m <- -1.5861 - 0.31082 * u - 0.083751 * u^2 + 0.0038915 * u^3
      s <- exp(-0.4803 - 0.082676 * u + 0.0030302 * u^2)
      s2 <- s^2
      sigma2 <- log((p - 1 + exp(s2)) / p)
      mu1 <- m + s2 / 2 - sigma2 / 2
      p.value <- pnorm(w1, mean = mu1, sd = sqrt(sigma2), lower.tail = FALSE)
      results <- list(statistic=c(W=wast),"p.value"=p.value, method = "Shapiro-Wilk test for Multivariate Skew-Normal Distributions", data.name=dname)
      class(results) = "htest"
      return(results)
    }
}



