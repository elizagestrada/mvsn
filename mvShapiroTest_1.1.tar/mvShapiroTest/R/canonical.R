canonical <- function(y, alpha, Omega, xi){
  n <- NA
  p <- NA
  n <- nrow(y)
  p <- ncol(y)
  omega_inv <- diag(p) * 1/sqrt(diag(Omega)) #diag(1/sqrt(diag(Omega)))
  Omega_bar <- omega_inv %*% Omega %*% omega_inv
  omega <-   diag(sqrt(diag(Omega)))
  delta <- Omega_bar %*% (alpha) / as.numeric(sqrt(1 +  alpha  %*% Omega_bar %*% (alpha)))
  mu_z  <- sqrt(2/pi) * delta  
  Sigma_z <- Omega_bar - (mu_z) %*% t(mu_z) 
  Sigma_y <- omega %*% Sigma_z %*% omega 
  
  # Square root of Omega inverse 
  eigenv.Omega <- eigen(Omega, symmetric = TRUE)
  e.vec.Omega <- as.matrix(eigenv.Omega$vectors)
  sqrt.inv.Omega <- e.vec.Omega %*% diag(1 / sqrt(eigenv.Omega$values), ncol = p) %*% t(e.vec.Omega) #square root (invOmega)
  
  # Matrix M
  M <- sqrt.inv.Omega %*% Sigma_y %*% sqrt.inv.Omega  
  
  # Spectral decomposition of M
  eigenv.M <- eigen(M, symmetric = TRUE)
  
  # Matrix Q
  Q <- as.matrix(eigenv.M$vectors)
  
  # Matrix H
  H <- sqrt.inv.Omega %*% Q
  
  z <- matrix(rep(NA, p*n), nrow = n, ncol = p)
  for(i in 1:p){
    z[ , i] <- y[ , i] - xi[i]  
  }
  
  
  # Canonical form
  Y.star <- t(H) %*%  t(z)
  return(t(Y.star))  
}
